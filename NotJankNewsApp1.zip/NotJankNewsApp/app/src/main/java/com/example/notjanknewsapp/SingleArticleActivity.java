package com.example.notjanknewsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;


public class SingleArticleActivity extends AppCompatActivity {

    Bitmap Image;
    String ImageURL;
    String Headline;
    String Abstract;
    String LeadGrapg;
    String Section;

    Boolean SaveQ;

    ImageView main;
    TextView headLine;
    TextView abstractText;
    ImageButton backer;
    ImageButton commentButton;
    Button saveButton;
    private DatabaseReference mDatabase;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_article);

        main = findViewById(R.id.MainImageImageView);
        headLine = findViewById(R.id.headlineTextView);
        abstractText = findViewById(R.id.mainArticleTextView);
        backer = findViewById(R.id.bye);
        commentButton = findViewById(R.id.commentButton);
        saveButton = findViewById(R.id.saveButton);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        Headline = getIntent().getStringExtra("HEADLINE");
        Abstract = getIntent().getStringExtra("ABSTRACT");
        LeadGrapg = getIntent().getStringExtra("LEAD");
        Section = getIntent().getStringExtra("SECTION");
        SaveQ = getIntent().getBooleanExtra("SAVEORUNSAVE", false);
        byte[] barray = getIntent().getByteArrayExtra("IMAGE");
        Image = BitmapFactory.decodeByteArray(barray, 0, barray.length);

        ImageURL = getIntent().getStringExtra("IMAGEEURL");

        main.setImageBitmap(Image);
        headLine.setText(Headline);
        abstractText.setText(Abstract +" "+LeadGrapg);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(SaveQ)
                {
                    mDatabase.child("Users").child(mAuth.getCurrentUser().getUid()).child(Headline).child("Abstract").setValue(Abstract);
                    mDatabase.child("Users").child(mAuth.getCurrentUser().getUid()).child(Headline).child("LeadGraph").setValue(LeadGrapg);
                    mDatabase.child("Users").child(mAuth.getCurrentUser().getUid()).child(Headline).child("Section").setValue(Section);
                    mDatabase.child("Users").child(mAuth.getCurrentUser().getUid()).child(Headline).child("Image").setValue(ImageURL);

                }
                else
                {
                    mDatabase.child("Users").child(mAuth.getCurrentUser().getUid()).child(Headline).removeValue();
                }



            }
        });

        commentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SingleArticleActivity.this, commentOnActivity.class);
                intent.putExtra("HEADLINE", Headline);
                intent.putExtra("SECTION", Section);
                intent.putExtra("ABSTRACT", Abstract);
                intent.putExtra("LEAD", LeadGrapg);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                Image.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] byteArray = stream.toByteArray();
                intent.putExtra("IMAGE", byteArray);
                startActivity(intent);
            }
        });

        backer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(SaveQ){
                    finish();
                }
                else
                {
                    Intent intent = new Intent(SingleArticleActivity.this, ProfileActivity.class);
                    startActivity(intent);
                }

            }
        });

    }
}