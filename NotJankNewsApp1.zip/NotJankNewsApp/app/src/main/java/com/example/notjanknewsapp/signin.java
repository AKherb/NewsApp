package com.example.notjanknewsapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;



import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class signin extends AppCompatActivity {


    private Button signIn1;
    private EditText emial1;
    private EditText pword1;

    ImageButton backButton;
    ImageButton googleSignIn;

    private FirebaseAuth mAuth;
    //private static final int RC_SIGN_IN = 123;
     //private GoogleSignInClient mGoogleSignInClient;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        signIn1 = findViewById(R.id.signUp2);
        emial1 = findViewById(R.id.email2);
        pword1 = findViewById(R.id.pword2);
        mAuth = FirebaseAuth.getInstance();
        backButton = findViewById(R.id.byebyebyebye1);
        googleSignIn = findViewById(R.id.GoogleSignIn);

        ConstraintLayout constraintLayout = findViewById(R.id.signInActivityLayout);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(7000);
        animationDrawable.setExitFadeDuration(7000);
        animationDrawable.start();

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        signIn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("TAG", emial1.getText().toString() + pword1.getText().toString());
                String email = emial1.getText().toString();
                String password = pword1.getText().toString();

                if(!password.equals("") && !email.equals(""))
                {
                    mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(signin.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful())
                            {
                                Log.d("TAG", "YAY");
                                Toast.makeText(signin.this, "Signed In Successfully",
                                        Toast.LENGTH_LONG).show();


                                Log.d("tag", "flop");
                                Intent intent = new Intent(signin.this, HomeScreen.class);
                                startActivity(intent);
                            }
                            else
                            {
                                Toast.makeText(signin.this, "Invalid Credentials, please try again!",
                                        Toast.LENGTH_LONG).show();
                            }
                        }
                    });

                    //mAuth.signIn

                }
                else
                {
                    Toast.makeText(signin.this, "Please type in your email and password",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        googleSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                //startActivityForResult(signInIntent, RC_SIGN_IN);
            }
        });



    }
}