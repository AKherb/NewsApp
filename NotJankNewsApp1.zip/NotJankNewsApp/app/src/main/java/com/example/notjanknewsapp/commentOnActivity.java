package com.example.notjanknewsapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class commentOnActivity extends AppCompatActivity {

    Bitmap Image;
    String Headline;
    String Abstract;
    String LeadGrapg;
    String Section;


    TextView headlineView;
    ImageButton backButton;
    Button saveCAR;
    EditText commentSpace;
    LinearLayout priorComments;
    RatingBar ratingBar;
    TextView averageRatingText;
    private DatabaseReference mDatabase;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment_on);

        ConstraintLayout constraintLayout = findViewById(R.id.saveComment);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(7000);
        animationDrawable.setExitFadeDuration(7000);
        animationDrawable.start();

        mDatabase = FirebaseDatabase.getInstance().getReference();

        headlineView = findViewById(R.id.headlineTextViewINCOMMENT2);
        backButton = findViewById(R.id.byebye);
        saveCAR = findViewById(R.id.saveCAR);
        commentSpace = findViewById(R.id.yourComment);
        priorComments = findViewById(R.id.priorComments);
        ratingBar = findViewById(R.id.ratingBar);
        averageRatingText = findViewById(R.id.averageRating);


        Headline = getIntent().getStringExtra("HEADLINE");
        Abstract = getIntent().getStringExtra("ABSTRACT");
        LeadGrapg = getIntent().getStringExtra("LEAD");
        Section = getIntent().getStringExtra("SECTION");
        byte[] barray = getIntent().getByteArrayExtra("IMAGE");
        Image = BitmapFactory.decodeByteArray(barray, 0, barray.length);

        headlineView.setText(Headline);


        try {




            Task IhaveNOClue = mDatabase.child("All_Comments").child(Headline).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    DataSnapshot tf = task.getResult();
                    double rating = 0;
                    double fortimes = 0;
                    for (DataSnapshot childSnapshot : tf.getChildren()) {

                        fortimes++;
                        String childKey = childSnapshot.getKey();

                        TextView textView = new TextView(commentOnActivity.this);
                        textView.setGravity(Gravity.CENTER);
                        textView.setText(childKey);
                        priorComments.addView(textView);

                        rating += Float.valueOf(childSnapshot.getValue().toString());
                        Log.d("IHAVENOCLUE", childKey + "\t\t"+childSnapshot.getValue());
                    }

                    try {
                        double averageRating = rating/fortimes;
                        averageRatingText.setText("Average Rating: " + averageRating);
                    }
                    catch (Exception e)
                    {
                        averageRatingText.setText("Average Rating: 0");
                    }




                    if(!tf.hasChildren())
                    {
                        TextView textView = new TextView(commentOnActivity.this);
                        textView.setGravity(Gravity.CENTER);
                        textView.setText("No One Has Commented Yet. Be the First!");
                    }
                }
            });



        }
        catch (Exception e)
        {
            Log.d("IHAVENOCLUE", e.toString());
        }



        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        saveCAR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                float rating = ratingBar.getRating();
                String comment = commentSpace.getText().toString();

                mDatabase.child("All_Comments").child(Headline).child(comment).child("rating").getParent().setValue(rating);


                finish();
            }
        });

    }
}