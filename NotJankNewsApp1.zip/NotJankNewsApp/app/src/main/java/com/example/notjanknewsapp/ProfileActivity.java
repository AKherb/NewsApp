package com.example.notjanknewsapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class ProfileActivity extends AppCompatActivity {

    ImageButton backer;
    TextView whoRU;
    TextView pastSearches;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    Button signOutButton;
    LinearLayout ProfileInflate;

    Bitmap YImagY;

    String Headliney;
    String Abstracty;
    String Imagey;
    String LeadParay;
    String Sectiony;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        whoRU = findViewById(R.id.whoRU);
        ConstraintLayout constraintLayout = findViewById(R.id.ProfileActivityLayout);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(7000);
        animationDrawable.setExitFadeDuration(7000);
        animationDrawable.start();
        signOutButton = findViewById(R.id.signOut);
        //pastSearches = findViewById(R.id.pastSearches);
        ProfileInflate = findViewById(R.id.ProfileToBeInflated);

        signOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
                mAuth.signOut();
                startActivity(intent);

            }
        });

        backer = findViewById(R.id.byebyebye);
        backer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(ProfileActivity.this, HomeScreen.class);
                    startActivity(intent);
                }
                catch (Exception e)
                {
                    Intent intent = new Intent(ProfileActivity.this, HomeScreen.class);
                    startActivity(intent);
                }

            }
        });

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        FirebaseUser user = mAuth.getCurrentUser();
        String email = user.getEmail();
        whoRU.setText(email);




        try {


            Task getShit = mDatabase.child("Users").child(mAuth.getCurrentUser().getUid()).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {

                    LayoutInflater l = getLayoutInflater();
                    LinearLayout containerLayout = findViewById(R.id.ProfileToBeInflated);
                    DataSnapshot tf = task.getResult();
                    for (DataSnapshot childSnapshot : tf.getChildren()) {




                        View o = l.inflate(R.layout.newsviewonhomescreen, findViewById(R.id.ProfileToBeInflated), false);
                        String childKey = childSnapshot.getKey();
                        Headliney = childKey;

                        Task getSHITSHIT = mDatabase.child("Users").child(mAuth.getCurrentUser().getUid()).child(childKey).child("Abstract").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DataSnapshot> task) {
                                Abstracty = task.getResult().getValue(String.class);
                                Log.d("GETSHITSHIT", Abstracty);

                            }
                        });

                        getSHITSHIT = mDatabase.child("Users").child(mAuth.getCurrentUser().getUid()).child(childKey).child("LeadGraph").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DataSnapshot> task) {
                                LeadParay = task.getResult().getValue(String.class);
                                Log.d("GETSHITSHIT", LeadParay);

                            }
                        });

                        getSHITSHIT = mDatabase.child("Users").child(mAuth.getCurrentUser().getUid()).child(childKey).child("Image").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DataSnapshot> task) {
                                Imagey = task.getResult().getValue(String.class);
                                Log.d("GETSHITSHIT", Imagey);
                                ImageView ImageV = o.findViewById(R.id.imageOfArticle);
                                AsyncThreadY asyncThread1 = new AsyncThreadY();
                                try {
                                    asyncThread1.execute().get();
                                    ImageV.setImageBitmap(YImagY);
                                }
                                catch (Exception e)
                                {
                                    Log.d("EXCEPTION", e.toString());
                                }


                            }
                        });

                        getSHITSHIT = mDatabase.child("Users").child(mAuth.getCurrentUser().getUid()).child(childKey).child("Section").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DataSnapshot> task) {
                                Sectiony = task.getResult().getValue(String.class);
                                Log.d("GETSHITSHIT", Sectiony);
                                TextView SectionV = o.findViewById(R.id.section);
                                Log.d("BEFORE PUTTING IN", Sectiony.toString());
                                SectionV.setText(Sectiony);

                            }
                        });



                        TextView HeadLineV = o.findViewById(R.id.Headline);
                        HeadLineV.setText(Headliney);







                        containerLayout.addView(o);

                        o.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent intent = new Intent(ProfileActivity.this, SingleArticleActivity.class);
                                intent.putExtra("HEADLINE", Headliney);
                                intent.putExtra("SECTION", Sectiony);
                                intent.putExtra("ABSTRACT", Abstracty);
                                intent.putExtra("LEAD", LeadParay);
                                intent.putExtra("SAVEORUNSAVE", false);
                                intent.putExtra("IMAGEEURL", Imagey);
                                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                                YImagY.compress(Bitmap.CompressFormat.PNG, 100, stream);
                                byte[] byteArray = stream.toByteArray();
                                intent.putExtra("IMAGE", byteArray);
                                startActivity(intent);
                            }
                        });

                    }
                }
            });
        }
        catch (Exception e)
        {
            Log.d("ERROR", e.toString());
        }








    }
    public class AsyncThreadY extends AsyncTask<Void, Void, Void>
    {
        @Override
        protected Void doInBackground(Void... voids) {

            InputStream inputStream = null;
            try {
                inputStream = new URL(Imagey).openStream();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            YImagY = BitmapFactory.decodeStream(inputStream);



            return null;
        }
    }
}