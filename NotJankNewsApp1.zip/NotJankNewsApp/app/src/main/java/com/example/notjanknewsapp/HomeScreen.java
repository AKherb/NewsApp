package com.example.notjanknewsapp;

import static android.os.PersistableBundle.readFromStream;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;


public class HomeScreen extends AppCompatActivity {

    public static final String EXTRAEXTRA_CODE = "code";

    ImageButton searchButton;
    ImageButton profile;
    EditText searchText;
    TextView[] headlinesV = new TextView[10];
    String[] headliners = new String[10];

    Bitmap[] articldimagers = new Bitmap[10];

    String[] articleimagersURL = new String[10];
    TextView[] sectionsV = new TextView[10];
    String[] sectioners = new String[10];
    String[] abstracters = new String[10];
    String[] leaders = new String[10];
    ImageView[] articleimageV = new ImageView[10];
    Switch[] bookmarkV = new Switch[10];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        searchButton = findViewById(R.id.go);
        searchText = findViewById(R.id.search);
        profile = findViewById(R.id.profile);

        ConstraintLayout constraintLayout = findViewById(R.id.homeActivityLayout);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(7000);
        animationDrawable.setExitFadeDuration(7000);
        animationDrawable.start();

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeScreen.this, ProfileActivity.class);
                startActivity(intent);
            }
        });

        searchButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.R)
            @Override
            public void onClick(View v) {


                View[] o = new View[10];
                LayoutInflater l = getLayoutInflater();
                LinearLayout containerLayout = findViewById(R.id.toBeInflatedLayout);





                AsyncThread asyncThread = new AsyncThread();
                try {
                    asyncThread.execute().get();

                }
                catch (Exception e)
                {
                    Log.d("EXCEPTION", e.toString());
                }

                for(int i = 0; i < 10; i++)
                {

                    o[i] = l.inflate(R.layout.newsviewonhomescreen, findViewById(R.id.toBeInflatedLayout), false);



                    headlinesV[i] = o[i].findViewById(R.id.Headline);
                    headlinesV[i].setText(headliners[i]);


                    sectionsV[i] = o[i].findViewById(R.id.section);
                    sectionsV[i].setText(sectioners[i]);

                    articleimageV[i] = o[i].findViewById(R.id.imageOfArticle);
                    articleimageV[i].setImageBitmap(articldimagers[i]);

                    //bookmarkV[i] = o[i].findViewById(R.id.bookMarkSwitch);

                    containerLayout.addView(o[i]);



                }

                o[0].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(HomeScreen.this, SingleArticleActivity.class);
                        intent.putExtra("HEADLINE", headliners[0]);
                        intent.putExtra("SECTION", sectioners[0]);
                        intent.putExtra("ABSTRACT", abstracters[0]);
                        intent.putExtra("LEAD", leaders[0]);
                        intent.putExtra("IMAGEEURL", articleimagersURL[0]);
                        intent.putExtra("SAVEORUNSAVE", true);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        articldimagers[0].compress(Bitmap.CompressFormat.PNG, 100, stream);
                        byte[] byteArray = stream.toByteArray();
                        intent.putExtra("IMAGE", byteArray);
                        startActivity(intent);
                    }
                });
                o[1].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(HomeScreen.this, SingleArticleActivity.class);
                        intent.putExtra("HEADLINE", headliners[1]);
                        intent.putExtra("SECTION", sectioners[1]);
                        intent.putExtra("ABSTRACT", abstracters[1]);
                        intent.putExtra("LEAD", leaders[1]);
                        intent.putExtra("IMAGEEURL", articleimagersURL[1]);
                        intent.putExtra("SAVEORUNSAVE", true);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        articldimagers[1].compress(Bitmap.CompressFormat.PNG, 100, stream);
                        byte[] byteArray = stream.toByteArray();
                        intent.putExtra("IMAGE", byteArray);
                        startActivity(intent);
                    }
                });
                o[2].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(HomeScreen.this, SingleArticleActivity.class);
                        intent.putExtra("HEADLINE", headliners[2]);
                        intent.putExtra("SECTION", sectioners[2]);
                        intent.putExtra("ABSTRACT", abstracters[2]);
                        intent.putExtra("LEAD", leaders[2]);
                        intent.putExtra("IMAGEEURL", articleimagersURL[2]);
                        intent.putExtra("SAVEORUNSAVE", true);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        articldimagers[2].compress(Bitmap.CompressFormat.PNG, 100, stream);
                        byte[] byteArray = stream.toByteArray();
                        intent.putExtra("IMAGE", byteArray);
                        startActivity(intent);
                    }
                });
                o[3].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(HomeScreen.this, SingleArticleActivity.class);
                        intent.putExtra("HEADLINE", headliners[3]);
                        intent.putExtra("SECTION", sectioners[3]);
                        intent.putExtra("ABSTRACT", abstracters[3]);
                        intent.putExtra("LEAD", leaders[3]);
                        intent.putExtra("IMAGEEURL", articleimagersURL[3]);
                        intent.putExtra("SAVEORUNSAVE", true);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        articldimagers[3].compress(Bitmap.CompressFormat.PNG, 100, stream);
                        byte[] byteArray = stream.toByteArray();
                        intent.putExtra("IMAGE", byteArray);
                        startActivity(intent);
                    }
                });
                o[4].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(HomeScreen.this, SingleArticleActivity.class);
                        intent.putExtra("HEADLINE", headliners[4]);
                        intent.putExtra("SECTION", sectioners[4]);
                        intent.putExtra("ABSTRACT", abstracters[4]);
                        intent.putExtra("LEAD", leaders[4]);
                        intent.putExtra("SAVEORUNSAVE", true);
                        intent.putExtra("IMAGEEURL", articleimagersURL[4]);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        articldimagers[4].compress(Bitmap.CompressFormat.PNG, 100, stream);
                        byte[] byteArray = stream.toByteArray();
                        intent.putExtra("IMAGE", byteArray);
                        startActivity(intent);
                    }
                });
                o[5].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(HomeScreen.this, SingleArticleActivity.class);
                        intent.putExtra("HEADLINE", headliners[5]);
                        intent.putExtra("SECTION", sectioners[5]);
                        intent.putExtra("ABSTRACT", abstracters[5]);
                        intent.putExtra("LEAD", leaders[5]);
                        intent.putExtra("SAVEORUNSAVE", true);
                        intent.putExtra("IMAGEEURL", articleimagersURL[5]);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        articldimagers[5].compress(Bitmap.CompressFormat.PNG, 100, stream);
                        byte[] byteArray = stream.toByteArray();
                        intent.putExtra("IMAGE", byteArray);
                        startActivity(intent);
                    }
                });
                o[6].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(HomeScreen.this, SingleArticleActivity.class);
                        intent.putExtra("HEADLINE", headliners[6]);
                        intent.putExtra("SECTION", sectioners[6]);
                        intent.putExtra("ABSTRACT", abstracters[6]);
                        intent.putExtra("LEAD", leaders[6]);
                        intent.putExtra("SAVEORUNSAVE", true);
                        intent.putExtra("IMAGEEURL", articleimagersURL[6]);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        articldimagers[6].compress(Bitmap.CompressFormat.PNG, 100, stream);
                        byte[] byteArray = stream.toByteArray();
                        intent.putExtra("IMAGE", byteArray);
                        startActivity(intent);
                    }
                });
                o[7].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(HomeScreen.this, SingleArticleActivity.class);
                        intent.putExtra("HEADLINE", headliners[7]);
                        intent.putExtra("SECTION", sectioners[7]);
                        intent.putExtra("ABSTRACT", abstracters[7]);
                        intent.putExtra("SAVEORUNSAVE", true);
                        intent.putExtra("LEAD", leaders[7]);
                        intent.putExtra("IMAGEEURL", articleimagersURL[7]);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        articldimagers[7].compress(Bitmap.CompressFormat.PNG, 100, stream);
                        byte[] byteArray = stream.toByteArray();
                        intent.putExtra("IMAGE", byteArray);
                        startActivity(intent);
                    }
                });
                o[8].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(HomeScreen.this, SingleArticleActivity.class);
                        intent.putExtra("HEADLINE", headliners[8]);
                        intent.putExtra("SECTION", sectioners[8]);
                        intent.putExtra("ABSTRACT", abstracters[8]);
                        intent.putExtra("LEAD", leaders[8]);
                        intent.putExtra("SAVEORUNSAVE", true);
                        intent.putExtra("IMAGEEURL", articleimagersURL[8]);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        articldimagers[8].compress(Bitmap.CompressFormat.PNG, 100, stream);
                        byte[] byteArray = stream.toByteArray();
                        intent.putExtra("IMAGE", byteArray);
                        startActivity(intent);
                    }
                });
                o[9].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(HomeScreen.this, SingleArticleActivity.class);
                        intent.putExtra("HEADLINE", headliners[9]);
                        intent.putExtra("SECTION", sectioners[9]);
                        intent.putExtra("ABSTRACT", abstracters[9]);
                        intent.putExtra("LEAD", leaders[9]);
                        intent.putExtra("SAVEORUNSAVE", true);
                        intent.putExtra("IMAGEEURL", articleimagersURL[9]);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        articldimagers[9].compress(Bitmap.CompressFormat.PNG, 100, stream);
                        byte[] byteArray = stream.toByteArray();
                        intent.putExtra("IMAGE", byteArray);
                        startActivity(intent);
                    }
                });




            }
        });


    }

    public class AsyncThread extends AsyncTask<Void, Void, Void>
    {
        @Override
        protected Void doInBackground(Void...voids)
        {

            try {
                URL url = new URL("https://api.nytimes.com/svc/search/v2/articlesearch.json?q="+searchText.getText().toString()+"&api-key=x4a3q4hSjlgpdN7WCuU0ICXXsHEf0T3m");
                URLConnection connection = url.openConnection();
                InputStream is = connection.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                String str = "";
                String strCurrentLine;

                while ((strCurrentLine = br.readLine()) != null)
                {
                    str+=strCurrentLine;
                }

                Log.d("TAG", str);
                JSONObject json = new JSONObject(str);

                JSONObject response = new JSONObject(String.valueOf(json.getJSONObject("response")));
                JSONArray W = new JSONArray(String.valueOf((response.getJSONArray("docs"))));

                for(int i = 0; i < 10; i++)
                {
                    JSONObject WW = new JSONObject(String.valueOf(W.getJSONObject(i)));

                    JSONObject headline = new JSONObject(String.valueOf(WW.getJSONObject("headline")));

                    headliners[i] = headline.get("main").toString();
                    abstracters[i] = WW.get("abstract").toString();
                    leaders[i] = WW.get("lead_paragraph").toString();


                    org.jsoup.nodes.Document document = null;
                    String urString = "https://www.google.com/search?tbm=isch&q=" + headline.get("main").toString();
                    document = Jsoup.connect(urString).userAgent("Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36").get();
                    Elements imageElements = document.select("img");
                    if (!imageElements.isEmpty()) {
                        Element firstImage = imageElements.get(1);
                        String imageUrl = firstImage.attr("src");
                        System.out.println("First Image URL: " + imageUrl);

                        articleimagersURL[i] = imageUrl;

                        InputStream inputStream = new URL(imageUrl).openStream();
                        articldimagers[i] = BitmapFactory.decodeStream(inputStream);
                    }
                    else
                    {
                        Log.d("ERROR", "Nothing Found");
                    }


                    sectioners[i] = WW.get("section_name").toString();

                    Log.d("TAG", headliners[i]);
                    Log.d("TAG", sectioners[i]);
                }

            }
            catch (Exception e)
            {
                Log.d("ERROR", e.toString());
            }

            return null;
        }

    }

    private final class asynctask extends AsyncTask<Void, Void, Void>
    {

        @RequiresApi(api = Build.VERSION_CODES.R)
        @Override
        protected Void doInBackground(Void... voids) {
            String jsonResponse = "";
            HttpURLConnection urlConnection = null;
            InputStream inputStream = null;
            try {
                URL url = new URL("https://api.nytimes.com/svc/search/v2/articlesearch.json?q="+searchText.getText().toString()+"&api-key=x4a3q4hSjlgpdN7WCuU0ICXXsHEf0T3m");
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();
                inputStream = urlConnection.getInputStream();
                jsonResponse = String.valueOf(readFromStream(inputStream));



                if (urlConnection != null) {
                    urlConnection.disconnect ();

                }
                if (inputStream != null) {

                    inputStream.close ();
                }

            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            Log.d("TAG", jsonResponse);
            return null;
        }


    }


}